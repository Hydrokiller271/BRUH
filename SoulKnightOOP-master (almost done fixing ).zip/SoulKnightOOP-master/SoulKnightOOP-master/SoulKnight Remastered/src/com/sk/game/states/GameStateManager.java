package com.sk.game.states;

import com.sk.game.GamePanel;
import com.sk.game.graphics.Sprite;
import com.sk.game.utils.KeyHandler;
import com.sk.game.utils.MouseHandler;
import com.sk.game.utils.Vector2f;

import javax.xml.parsers.ParserConfigurationException;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

public class GameStateManager {

    private GameState states[] = new GameState[4];

   
    
    public static int width;
    public static int height;
    public static int oldFrameCount;

    private Thread thread;
    private Boolean running = false;

    private BufferedImage img;
    private Graphics2D gp2d;

    private GamePanel game;
    
    private MouseHandler mouse;
    private KeyHandler key;

    public static Vector2f map;

    public static final int PLAY = 0;
    public static final int MENU = 1;
    public static final int PAUSE = 2;
    public static final int GAMEOVER = 3;

   
    
    public int onTopState = 0;

    public static Font font;
    
    
    
//Constructor
    public GameStateManager() {
        map = new Vector2f(GamePanel.width, GamePanel.height);
        Vector2f.setWorldVar(map.x, map.y);
       
        

        font = new Font("res/font/font.png", 10, 10);
        Sprite.currentFont = font;
       
       add(1);
        
    }
//getState
    public boolean getState(int state) {
        return states[state] != null;
    }
//Pop
    public void pop(int state) {
        states[state] = null;
    }
    //Add
    public void add(int state) {
        if(states[state] != null)
            return;
        if(state == PLAY) {
                states[PLAY] = new PlayState(this);
        }
        if(state == MENU) {
            states[MENU] = new MenuState(this);
        }

        if(state == PAUSE) {
            states[PAUSE] = new PauseState(this);
        }

        if(state == GAMEOVER) {
            states[GAMEOVER] = new GameOverState(this);
        }
    }
    //Add
    public void addAndpop(int state) {
        addAndPop(state, 0);
    }
    //Add&Pop
    public void addAndPop(int state, int remove) {
        pop(remove);
        add(state);
    }
    //Update
    public void update() {
        for (int i = 0; i < states.length; i++) {
            if(states[i] != null) {
                states[i].update();
            }
        }
    }

    public void input(MouseHandler mouse, KeyHandler key) {
        for (int i = 0; i < states.length; i++) {
            if(states[i] != null) {
                states[i].input(mouse, key);
            }
        }
    }

    public void render(Graphics2D gp2d) {
        for (int i = 0; i < states.length; i++) {
            if(states[i] != null) {
                states[i].render(gp2d);
            }
        }
    }
    
    
    public MouseHandler getMouse() {
		return mouse;
	}



	public void setMouse(MouseHandler mouse) {
		this.mouse = mouse;
	}



	public KeyHandler getKey() {
		return key;
	}



	public void setKey(KeyHandler key) {
		this.key = key;
	}



	public int getWidth() {
		return width;
	}


    public static void setWidth(int width) {
		GamePanel.width = width;
	}



	public  int getHeight() {
		return height;
	}


	public static void setHeight(int height) {
		GamePanel.height = height;
	}

	//getRunningGSM
	public Boolean getRunning() {
		return game.getRunning();
	}

	//setRunningGSM
	public void setRunning(Boolean running) {
		game.setRunning(running);
	}

	public void gameStop() {
		System.exit(1);
	}

}
