package Driver.ui;

public interface ClickListener {
	
	public void onClick();
	
}
