package com.sk.game.entities;

import com.sk.game.graphics.Animation;
import com.sk.game.graphics.Sprite;
import com.sk.game.utils.*;

import java.awt.*;
import java.awt.image.BufferedImage;

public abstract class Entity {

    private final int UP = 3;
    private final int DOWN = 2;
    private final int RIGHT = 0;
    private final int LEFT = 1;
    private final int FALLEN = 4;
    protected int currentAnimation;

    protected Animation ani;
    protected Sprite sprite;
    protected Vector2f pos;
    protected TileCollision tc;

    protected int size;
    protected boolean up;
    protected boolean down;
    protected boolean right;
    protected boolean left;
    protected boolean attack;
    protected boolean fallen;
    protected boolean attackSpeed;
    protected boolean attackDuration;

    public boolean xCol = false;
    public boolean yCol = false;

    protected float dx;
    protected float dy;

    protected float maxSpeed = 2.5f;
    protected float acc = 1.75f;
    protected float deacc = 0.2f;

    protected AABB hitBounds;
    protected AABB bounds;

    public Entity(Sprite sprite, Vector2f origin, int size) {
        this.sprite = sprite;
        pos = origin;
        this.size = size;

        bounds = new AABB(origin, size, size);
        hitBounds = new AABB(origin, size, size);
        hitBounds.setXOffset(size / 2);
        ani = new Animation();
        setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), 10);

        tc = new TileCollision(this);
    }

    public void setSprite(Sprite sprite) {
        this.sprite = sprite;
    }
    public void setFallen(boolean b) {
        fallen = b;
    }
    public void setSize(int i) {
        size = i;
    }
    public int getSize() { return size; }

    public void setMaxSpeed(float f) {
        maxSpeed = f;
    }
    public float getMaxSpeed() { return maxSpeed; }
    public void setAcc(float f) { acc = f; }
    public float getAcc() { return acc; }
    public void setDeacc(float f) { deacc = f; }
    public float getDeacc() { return deacc; }

    public float getDx() { return dx; }
    public float getDy() { return dy; }

    public Animation getAnimation() { return ani; }
    public AABB getBounds() { return bounds; }

    public void setAnimation(int i, BufferedImage[] frames, int delay) {
        currentAnimation = i;
        ani.setFrames(frames);
        ani.setDelay(delay);
    }

    public void animate() {
        if (up) {
            if (currentAnimation != UP || ani.getDelay() == -1) {
                setAnimation(UP, sprite.getSpriteArray(UP), 5);
            }
        } else if (down) {
            if (currentAnimation != DOWN || ani.getDelay() == -1) {
                setAnimation(DOWN, sprite.getSpriteArray(DOWN), 5);
            }
        } else if (left) {
            if (currentAnimation != LEFT || ani.getDelay() == -1) {
                setAnimation(LEFT, sprite.getSpriteArray(LEFT), 5);
            }
        } else if (right) {
            if (currentAnimation != RIGHT || ani.getDelay() == -1) {
                setAnimation(RIGHT, sprite.getSpriteArray(RIGHT), 5);
            }
        } else if (fallen) {
            if (currentAnimation != FALLEN || ani.getDelay() == -1) {
                setAnimation(FALLEN, sprite.getSpriteArray(FALLEN), 10);
            }
        } else {
            setAnimation(currentAnimation, sprite.getSpriteArray(currentAnimation), -1);
        }
    }

    private void setHitBoxDirection() {
        if(up) {
            hitBounds.setYOffset(-size / 2);
            hitBounds.setXOffset(0) ;
        }
        else if(down) {
            hitBounds.setYOffset(size / 2);
            hitBounds.setXOffset(0);
        }
        else if(left) {
            hitBounds.setYOffset(0);
            hitBounds.setXOffset(-size / 2);
        }
        else if(right) {
            hitBounds.setYOffset(0);
            hitBounds.setXOffset(size / 2);
        }
    }

    public void update() {
        animate();
        setHitBoxDirection();
        ani.update();
    }

    public abstract void render(Graphics2D gp2d);
}
