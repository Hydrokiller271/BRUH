package com.sk.game.states;

import com.sk.game.GamePanel;
import com.sk.game.entities.Player;
import com.sk.game.graphics.Assets;
import com.sk.game.graphics.Sprite;
import com.sk.game.utils.KeyHandler;
import com.sk.game.utils.MouseHandler;
import com.sk.game.utils.Vector2f;
import com.sk.handler.Handler;
import com.sk.ui.UIManager;



import com.sk.game.states.*;
import com.sk.ui.ClickListener;
import com.sk.ui.UIImageButton;


import com.sk.game.GamePanel;

import java.awt.*;

public class MenuState extends GameState {

    private Font font;
    private Player player;
    private UIManager uiManager;
    private GameState[] states;
    private Sprite sprite;
    private Handler handler;
    private MouseHandler mouse;
    private KeyHandler key;
    
    public MenuState(GameStateManager gsm) {
        super(gsm);
        font = new Font("font/ZeldaFont.png", 16, 16);
        
        
        

      
        
        sprite = new Sprite("entity/linkFormatted.png");
        
        uiManager = new UIManager(gsm);
        
        uiManager.input(mouse, key);
        uiManager.addObject(new UIImageButton(200, 200, 128, 64, Assets.btn_start, new ClickListener() {
        	
        	
			@Override
			public void onClick() {
				
				System.out.println("YO");
				handler.getMouse().setUIManager(null);
				gsm.addAndPop(0, 1);
				
			
			}

			@Override
			public void test() {
				// TODO Auto-generated method stub
				
			}
		
        }));
        
        		
        uiManager.addObject(new UIImageButton(200, 400, 128, 64,Assets.btn_end, new ClickListener() {
    		@Override
    		public void onClick() {
    			gsm.getMouse().setUIManager(null);
    			gsm.gameStop();
    		}
    		@Override
    		public void test() {
    			System.out.println("YO");
    		}
        
        }));
        
    }

    public void update() {
        uiManager.update();
    }

    public void input(MouseHandler mouse, KeyHandler key) {
        uiManager.input(mouse, key);
    }

    public void render(Graphics2D gp2d) {
    	Sprite.drawArray(gp2d, font, "SOUL KNIGHT", new Vector2f(300, 300), 32, 32, 24, 0);
        uiManager.render(gp2d);
    }
}
