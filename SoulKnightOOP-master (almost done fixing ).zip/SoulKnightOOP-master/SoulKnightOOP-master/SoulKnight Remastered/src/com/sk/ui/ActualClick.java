package com.sk.ui;

public interface ActualClick {
	public void AClick();
}
